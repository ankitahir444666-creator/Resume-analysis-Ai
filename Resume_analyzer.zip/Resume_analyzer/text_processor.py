"""
text_processor.py
-----------------
Cleans and preprocesses resume/job-description text for NLP analysis.

We preserve TWO versions of the text:
  1. original_text  – the raw extracted text, used for section detection
                      (so we don't lose keywords like "Education", "GitHub", etc.)
  2. cleaned_text   – lowercase, normalised text used for TF-IDF and matching

Uses:  re, nltk
"""

import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# ── Download NLTK data quietly (only if missing) ────────────────────────────
def _ensure_nltk():
    for resource, path in [
        ("tokenizers/punkt", "punkt"),
        ("tokenizers/punkt_tab", "punkt_tab"),
        ("corpora/stopwords", "stopwords"),
    ]:
        try:
            nltk.data.find(resource)
        except LookupError:
            nltk.download(path, quiet=True)

_ensure_nltk()

# ── Compile regexes once ────────────────────────────────────────────────────
_MULTI_SPACE = re.compile(r"[ \t]+")
_MULTI_NEWLINE = re.compile(r"\n{3,}")
_URL = re.compile(
    r"https?://\S+|www\.\S+",
    re.IGNORECASE
)
_EMAIL = re.compile(r"\S+@\S+\.\S+")
_NON_ALPHA_NUM = re.compile(r"[^a-z0-9\s\+\#\.]")   # keep +, #, . for C++, C#, .NET

try:
    _STOPWORDS = set(stopwords.words("english"))
except LookupError:
    _STOPWORDS = set()


def clean_text(text: str) -> str:
    """
    Return a lightly cleaned version of *text*.

    Steps
    -----
    1. Lowercase
    2. Remove URLs and emails
    3. Remove special characters (keep +, #, . for language names)
    4. Collapse repeated whitespace
    5. Strip leading/trailing whitespace
    """
    if not text:
        return ""

    text = text.lower()
    text = _URL.sub(" ", text)
    text = _EMAIL.sub(" ", text)
    text = _NON_ALPHA_NUM.sub(" ", text)
    text = _MULTI_SPACE.sub(" ", text)
    text = _MULTI_NEWLINE.sub("\n\n", text)
    return text.strip()


def tokenize_and_filter(text: str, remove_stopwords: bool = True) -> list[str]:
    """
    Tokenise *text* and optionally remove stop-words.

    Returns a list of word tokens.
    """
    if not text:
        return []

    try:
        tokens = word_tokenize(text.lower())
    except LookupError:
        tokens = text.lower().split()

    # Keep only alphabetic tokens (length >= 2)
    tokens = [t for t in tokens if t.isalpha() and len(t) >= 2]

    if remove_stopwords:
        tokens = [t for t in tokens if t not in _STOPWORDS]

    return tokens


def detect_sections(original_text: str) -> dict[str, bool]:
    """
    Detect common resume sections using the *original* (uncleaned) text.

    Returns a dict mapping section name → True/False.

    We use the original text so that section headers (capitalised words)
    are not accidentally lost by cleaning.
    """
    text_lower = original_text.lower()

    section_patterns = {
        "contact":        [r"\b(email|phone|mobile|contact|address)\b", r"@"],
        "education":      [r"\b(education|degree|bachelor|master|b\.?sc|m\.?sc|b\.?tech|m\.?tech|university|college|gpa|cgpa)\b"],
        "skills":         [r"\b(skills|technical skills|technologies|competencies|proficiencies)\b"],
        "projects":       [r"\b(projects?|personal projects?|academic projects?|portfolio)\b"],
        "experience":     [r"\b(experience|work experience|internship|employment|professional experience|job)\b"],
        "certifications": [r"\b(certif(icate|ication)|certified|udemy|coursera|edx|completion)\b"],
        "github":         [r"github\.com|github"],
        "linkedin":       [r"linkedin\.com|linkedin"],
        "achievements":   [r"\b(achievement|award|honor|honour|winner|rank|scholarship|recognition)\b"],
    }

    detected = {}
    for section, patterns in section_patterns.items():
        detected[section] = any(
            re.search(p, text_lower) for p in patterns
        )

    return detected


def process_text(raw_text: str) -> dict:
    """
    Full preprocessing pipeline.

    Parameters
    ----------
    raw_text : str  – raw text from the PDF or job description input

    Returns
    -------
    dict with:
        original_text  (str)        – unchanged raw text
        cleaned_text   (str)        – cleaned text for NLP
        tokens         (list[str])  – filtered word tokens
        sections       (dict)       – detected resume sections
    """
    if not raw_text or not raw_text.strip():
        return {
            "original_text": "",
            "cleaned_text": "",
            "tokens": [],
            "sections": {s: False for s in [
                "contact", "education", "skills", "projects",
                "experience", "certifications", "github", "linkedin", "achievements"
            ]}
        }

    cleaned = clean_text(raw_text)
    tokens = tokenize_and_filter(cleaned, remove_stopwords=True)
    sections = detect_sections(raw_text)   # use original for section detection

    return {
        "original_text": raw_text,
        "cleaned_text": cleaned,
        "tokens": tokens,
        "sections": sections,
    }
