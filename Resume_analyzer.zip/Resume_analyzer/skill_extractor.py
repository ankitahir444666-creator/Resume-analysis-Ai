"""
skill_extractor.py
------------------
Detects skills in a block of text using a JSON-based skill dictionary.

Strategy
--------
- For each skill in skills.json, build a regex that matches the skill as a
  whole word (case-insensitive) inside the text.
- Skills are returned grouped by category.

This approach avoids simple substring matching (which would produce false
positives like matching "R" inside every word) by using word boundaries.
"""

import re
import json
import os

# Path to the skill dictionary
_SKILLS_FILE = os.path.join(os.path.dirname(__file__), "data", "skills.json")

# Cache the loaded skills so we don't re-read the file on every call
_skills_db: dict | None = None


def _load_skills() -> dict:
    """Load skills from JSON file. Returns an empty dict on failure."""
    global _skills_db
    if _skills_db is not None:
        return _skills_db

    if not os.path.exists(_SKILLS_FILE):
        print(f"  Warning: Skills file not found at '{_SKILLS_FILE}'.")
        _skills_db = {}
        return _skills_db

    try:
        with open(_SKILLS_FILE, "r", encoding="utf-8") as f:
            _skills_db = json.load(f)
    except json.JSONDecodeError as e:
        print(f"  Warning: skills.json is malformed – {e}")
        _skills_db = {}
    except Exception as e:
        print(f"  Warning: Could not load skills.json – {e}")
        _skills_db = {}

    return _skills_db


def _build_skill_pattern(skill: str) -> re.Pattern:
    """
    Build a compiled regex pattern that matches *skill* as a whole word.

    Special handling:
    - 'C++' is escaped by re.escape to 'C\\+\\+'
    - 'C#'  uses a lookahead since # is non-word
    - Short single-letter skills like 'R' or 'C' use strict word boundaries
    """
    escaped = re.escape(skill)

    # For skills that end in non-word characters like + or #, we can't use \b
    # at the end, so we use a lookahead for a non-word character or end-of-string.
    if re.search(r"[^a-zA-Z0-9]$", skill):
        pattern = rf"(?<![a-zA-Z0-9]){escaped}(?![a-zA-Z0-9])"
    else:
        pattern = rf"\b{escaped}\b"

    return re.compile(pattern, re.IGNORECASE)


# Pre-compile all skill patterns once when the module loads
def _build_all_patterns(skills_db: dict) -> dict[str, tuple[str, re.Pattern]]:
    """
    Returns a flat dict: lowercase_skill -> (original_skill, pattern)
    """
    patterns: dict[str, tuple[str, re.Pattern]] = {}
    for category, skill_list in skills_db.items():
        for skill in skill_list:
            key = skill.lower()
            if key not in patterns:
                patterns[key] = (skill, _build_skill_pattern(skill))
    return patterns


_skill_patterns: dict | None = None


def _get_skill_patterns() -> dict:
    global _skill_patterns
    if _skill_patterns is None:
        _skill_patterns = _build_all_patterns(_load_skills())
    return _skill_patterns


def extract_skills(text: str) -> dict:
    """
    Detect skills present in *text*.

    Parameters
    ----------
    text : str  – resume text or job description (raw or cleaned)

    Returns
    -------
    dict with:
        by_category  (dict)       – {category: [skill, …]} for matched skills
        all_skills   (list[str])  – flat list of all matched skill names
        total        (int)        – total number of distinct matched skills
    """
    if not text:
        return {"by_category": {}, "all_skills": [], "total": 0}

    skills_db = _load_skills()
    patterns = _get_skill_patterns()

    matched_keys: set[str] = set()

    for key, (original, pattern) in patterns.items():
        if pattern.search(text):
            matched_keys.add(key)

    # Group results by category
    by_category: dict[str, list[str]] = {}
    all_skills: list[str] = []

    for category, skill_list in skills_db.items():
        matched_in_cat = [
            skill for skill in skill_list
            if skill.lower() in matched_keys
        ]
        if matched_in_cat:
            by_category[category] = matched_in_cat
            all_skills.extend(matched_in_cat)

    return {
        "by_category": by_category,
        "all_skills": all_skills,
        "total": len(all_skills),
    }
