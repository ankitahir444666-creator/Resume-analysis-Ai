sample_job_descriptions/
# Sample Job Descriptions

These text files contain sample job descriptions you can paste directly into ResumeIQ.

## Files

- `jd_python_developer.txt`
- `jd_data_analyst.txt`
- `jd_ml_intern.txt`
- `jd_flutter_developer.txt`

## Usage

Open the .txt file, copy all the text, then paste it into the ResumeIQ job description prompt.
