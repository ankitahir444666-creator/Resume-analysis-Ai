"""
sample_resumes/create_sample_pdf.py
------------------------------------
Creates sample PDF resumes for testing purposes.

Run this once:
    python sample_resumes/create_sample_pdf.py

Requires:  pip install reportlab
(reportlab is only needed for this helper — NOT for the main application)
"""

import sys
import os

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
except ImportError:
    print("reportlab is not installed.")
    print("Install it with:  pip install reportlab")
    print()
    print("Alternatively, you can use any PDF of your own resume.")
    sys.exit(1)


def _add_line(c, y, text, font="Helvetica", size=11, bold=False):
    if bold:
        font = "Helvetica-Bold"
    c.setFont(font, size)
    c.drawString(2 * cm, y, text)
    return y - (size + 4)


def create_sample_pdf(output_path: str, template: str = "data_analyst"):
    """Create a sample resume PDF."""

    templates = {
        "data_analyst": _template_data_analyst,
        "ml_intern":    _template_ml_intern,
        "python_dev":   _template_python_dev,
        "flutter_dev":  _template_flutter_dev,
    }

    fn = templates.get(template, _template_data_analyst)
    fn(output_path)
    print(f"  Created: {output_path}")


def _template_data_analyst(output_path):
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    y = height - 2 * cm

    lines = [
        ("JANE DOE", 16, True),
        ("Email: jane.doe@email.com  |  Phone: +91 9876543210", 10, False),
        ("LinkedIn: linkedin.com/in/janedoe  |  GitHub: github.com/janedoe", 10, False),
        ("", 6, False),
        ("EDUCATION", 13, True),
        ("B.Sc. Computer Science — State University, 2024 (CGPA: 8.5)", 11, False),
        ("", 6, False),
        ("SKILLS", 13, True),
        ("Programming:  Python, SQL, R", 11, False),
        ("Data Tools:   Pandas, NumPy, Matplotlib, Seaborn, Excel, Power BI", 11, False),
        ("Other:        Git, GitHub, Jupyter, Statistics", 11, False),
        ("", 6, False),
        ("PROJECTS", 13, True),
        ("1. Sales Dashboard (Python, Pandas, Matplotlib)", 11, True),
        ("   Analysed 50,000+ sales records; built interactive charts.", 11, False),
        ("2. Customer Churn Prediction (Scikit-learn, Python)", 11, True),
        ("   Achieved 87% accuracy; reduced churn by identifying at-risk users.", 11, False),
        ("3. COVID-19 Data Analysis (Pandas, Seaborn)", 11, True),
        ("   Visualised trends across 150 countries using public WHO data.", 11, False),
        ("", 6, False),
        ("CERTIFICATIONS", 13, True),
        ("  Google Data Analytics Certificate — Coursera, 2023", 11, False),
        ("  Python for Data Science — Udemy, 2022", 11, False),
        ("", 6, False),
        ("ACHIEVEMENTS", 13, True),
        ("  Winner — University Datathon 2023 (Team of 3)", 11, False),
        ("  Dean's List — 3 semesters", 11, False),
    ]

    for text, size, bold in lines:
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(2 * cm, y, text)
        y -= (size + 6)
        if y < 2 * cm:
            c.showPage()
            y = height - 2 * cm

    c.save()


def _template_ml_intern(output_path):
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    y = height - 2 * cm

    lines = [
        ("ALEX KUMAR", 16, True),
        ("alex.kumar@email.com | +91 9988776655", 10, False),
        ("GitHub: github.com/alexkumar | LinkedIn: linkedin.com/in/alexkumar", 10, False),
        ("", 6, False),
        ("EDUCATION", 13, True),
        ("B.Tech Artificial Intelligence — Tech Institute, 2025 (CGPA: 8.9)", 11, False),
        ("", 6, False),
        ("SKILLS", 13, True),
        ("ML/AI:        Machine Learning, Deep Learning, NLP, Scikit-learn", 11, False),
        ("Frameworks:   TensorFlow, PyTorch, Keras", 11, False),
        ("Programming:  Python, R", 11, False),
        ("Data:         Pandas, NumPy, Matplotlib, Seaborn, Jupyter", 11, False),
        ("Tools:        Git, GitHub, VS Code", 11, False),
        ("", 6, False),
        ("PROJECTS", 13, True),
        ("1. Sentiment Analysis on Twitter Data (NLP, BERT)", 11, True),
        ("   Classified 1M+ tweets; F1-score of 0.91 using fine-tuned BERT.", 11, False),
        ("2. Image Classification — CIFAR-10 (PyTorch, CNN)", 11, True),
        ("   Built a CNN achieving 93% test accuracy.", 11, False),
        ("3. House Price Regression (Scikit-learn, XGBoost)", 11, True),
        ("   RMSE of 8,500 on Kaggle dataset; top 12% on leaderboard.", 11, False),
        ("", 6, False),
        ("EXPERIENCE", 13, True),
        ("ML Research Intern — AI Lab, State University (Jun–Aug 2024)", 11, True),
        ("  Assisted in training object detection models (YOLO v8).", 11, False),
        ("  Wrote data augmentation pipelines in Python.", 11, False),
        ("", 6, False),
        ("CERTIFICATIONS", 13, True),
        ("  Deep Learning Specialization — Coursera (Andrew Ng), 2023", 11, False),
        ("  Machine Learning A-Z — Udemy, 2022", 11, False),
    ]

    for text, size, bold in lines:
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(2 * cm, y, text)
        y -= (size + 6)
        if y < 2 * cm:
            c.showPage()
            y = height - 2 * cm

    c.save()


def _template_python_dev(output_path):
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    y = height - 2 * cm

    lines = [
        ("PRIYA SHARMA", 16, True),
        ("priya@email.com | +91 9000011111", 10, False),
        ("GitHub: github.com/priyasharma | LinkedIn: linkedin.com/in/priyasharma", 10, False),
        ("", 6, False),
        ("EDUCATION", 13, True),
        ("B.Tech Computer Science — National Tech University, 2024 (CGPA: 8.2)", 11, False),
        ("", 6, False),
        ("SKILLS", 13, True),
        ("Languages: Python, JavaScript, SQL, Bash", 11, False),
        ("Backend:   Flask, Django, FastAPI, REST API", 11, False),
        ("Database:  MySQL, PostgreSQL, SQLite", 11, False),
        ("Tools:     Git, GitHub, Docker, Linux, VS Code, Postman", 11, False),
        ("Other:     Pandas, NumPy, Agile, Jira", 11, False),
        ("", 6, False),
        ("EXPERIENCE", 13, True),
        ("Backend Developer Intern — StartupX (Jan–Jun 2024)", 11, True),
        ("  Built 12 REST API endpoints in Flask; improved response time by 30%.", 11, False),
        ("  Implemented JWT authentication and PostgreSQL migrations.", 11, False),
        ("", 6, False),
        ("PROJECTS", 13, True),
        ("1. Task Management API (Flask, PostgreSQL, Docker)", 11, True),
        ("   Full CRUD REST API; Dockerised; documented with Swagger.", 11, False),
        ("2. URL Shortener (FastAPI, SQLite)", 11, True),
        ("   Handles 1,000+ requests/sec; click analytics dashboard included.", 11, False),
        ("", 6, False),
        ("CERTIFICATIONS", 13, True),
        ("  Python Backend Development — Udemy, 2023", 11, False),
        ("", 6, False),
        ("ACHIEVEMENTS", 13, True),
        ("  2nd place — HackIndia 2023 (Backend track)", 11, False),
    ]

    for text, size, bold in lines:
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(2 * cm, y, text)
        y -= (size + 6)
        if y < 2 * cm:
            c.showPage()
            y = height - 2 * cm

    c.save()


def _template_flutter_dev(output_path):
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    y = height - 2 * cm

    lines = [
        ("ROHAN VERMA", 16, True),
        ("rohan.verma@email.com | +91 9111122222", 10, False),
        ("GitHub: github.com/rohanv | LinkedIn: linkedin.com/in/rohanverma", 10, False),
        ("", 6, False),
        ("EDUCATION", 13, True),
        ("B.E. Information Technology — City Engineering College, 2025", 11, False),
        ("", 6, False),
        ("SKILLS", 13, True),
        ("Mobile:    Flutter, Dart, Android, iOS", 11, False),
        ("Backend:   Firebase, REST API, Node.js", 11, False),
        ("Tools:     Android Studio, Git, GitHub, Figma, VS Code", 11, False),
        ("Other:     Kotlin, Agile", 11, False),
        ("", 6, False),
        ("PROJECTS", 13, True),
        ("1. FitTracker — Fitness App (Flutter, Firebase)", 11, True),
        ("   Cross-platform app with real-time sync; 500+ users on Play Store.", 11, False),
        ("2. E-Commerce App (Flutter, REST API, Node.js)", 11, True),
        ("   Payment gateway integration; push notifications via FCM.", 11, False),
        ("3. Chat App (Flutter, Firebase Realtime Database)", 11, True),
        ("   Real-time messaging with image sharing and read receipts.", 11, False),
        ("", 6, False),
        ("EXPERIENCE", 13, True),
        ("Flutter Intern — MobileApps Co. (Mar–Aug 2024)", 11, True),
        ("  Contributed to 2 production Flutter apps shipped to 10k+ users.", 11, False),
        ("", 6, False),
        ("CERTIFICATIONS", 13, True),
        ("  Flutter & Dart — The Complete Guide (Udemy), 2023", 11, False),
        ("", 6, False),
        ("ACHIEVEMENTS", 13, True),
        ("  Best App Award — College Tech Fest 2023", 11, False),
    ]

    for text, size, bold in lines:
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(2 * cm, y, text)
        y -= (size + 6)
        if y < 2 * cm:
            c.showPage()
            y = height - 2 * cm

    c.save()


if __name__ == "__main__":
    out_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(out_dir, exist_ok=True)

    print("\nCreating sample PDF resumes...\n")

    for name in ["data_analyst", "ml_intern", "python_dev", "flutter_dev"]:
        out_file = os.path.join(out_dir, f"sample_{name}.pdf")
        create_sample_pdf(out_file, template=name)

    print("\nAll sample PDFs created in 'sample_resumes/'")
    print("Use them with:  python main.py")
