"""
e2e_test.py
-----------
End-to-end test that runs the full pipeline on a sample PDF
and verifies the HTML report is created correctly.

This is NOT part of the main application — it's for verification only.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from resume_parser    import extract_resume_text
from text_processor   import process_text
from skill_extractor  import extract_skills
from job_matcher      import analyse_match
from resume_scorer    import compute_resume_score, score_label
from role_recommender import recommend_roles
from suggestions      import generate_suggestions
from report_generator import generate_report

# ── Sample job description (Data Analyst) ─────────────────────────────────────
JD = """
Job Title: Data Analyst
Company: DataInsight Analytics

Required Skills:
Python, Pandas, NumPy, SQL, Excel, Matplotlib, Seaborn, Power BI, Statistics, Git, Communication

Responsibilities:
- Collect, clean, and analyse large datasets using Python and SQL
- Build dashboards using Power BI or Tableau
- Visualise data with Matplotlib, Seaborn, or Plotly
- Collaborate with teams using Git and GitHub
- Prepare clear reports and presentations
"""

PDF = os.path.join("sample_resumes", "sample_data_analyst.pdf")


def run():
    print("\n" + "="*60)
    print("  ResumeIQ — End-to-End Test")
    print("="*60)

    # Step 1: Parse PDF
    print("\n[1/7] Parsing PDF...")
    result = extract_resume_text(PDF)
    assert result["success"], f"PDF parse failed: {result['error']}"
    raw = result["text"]
    print(f"  ✓ Extracted {len(raw)} characters from {result['pages']} page(s).")

    # Step 2: Process text
    print("\n[2/7] Processing text...")
    processed = process_text(raw)
    assert processed["tokens"], "No tokens found"
    print(f"  ✓ {len(processed['tokens'])} tokens.")

    # Step 3: Extract resume skills
    print("\n[3/7] Extracting resume skills...")
    resume_skills_result = extract_skills(raw)
    resume_skills = resume_skills_result["all_skills"]
    assert resume_skills, "No skills detected in resume"
    print(f"  ✓ {len(resume_skills)} skills: {', '.join(resume_skills[:8])}...")

    # Step 4: Extract JD skills
    print("\n[4/7] Analysing job description...")
    jd_processed = process_text(JD)
    jd_skills_result = extract_skills(JD)
    jd_skills = jd_skills_result["all_skills"]
    print(f"  ✓ {len(jd_skills)} JD skills: {', '.join(jd_skills[:6])}...")

    # Step 5: Match analysis
    print("\n[5/7] Computing match scores...")
    match = analyse_match(
        resume_skills, jd_skills,
        processed["cleaned_text"], jd_processed["cleaned_text"]
    )
    print(f"  ✓ Skill Match: {match['skill_match_score']}%")
    print(f"  ✓ TF-IDF Sim:  {match['tfidf_score']}%")
    print(f"  ✓ Final Match: {match['final_match_score']}%")
    print(f"  ✓ Matched:   {match['matched_skills']}")
    print(f"  ✓ Missing:   {match['missing_skills']}")

    # Step 6: Quality, roles, suggestions
    print("\n[6/7] Quality score, roles & suggestions...")
    quality = compute_resume_score(processed["sections"])
    label = score_label(quality["total_score"])
    recommended = recommend_roles(resume_skills, top_n=3)
    suggestions = generate_suggestions(
        processed["sections"], match["missing_skills"],
        quality["breakdown"], raw
    )
    print(f"  ✓ Quality: {quality['total_score']}/100 ({label})")
    print(f"  ✓ Sections: {processed['sections']}")
    print(f"  ✓ Roles: {[r['role'] for r in recommended]}")
    print(f"  ✓ {len(suggestions)} suggestion(s).")

    # Step 7: Generate report
    print("\n[7/7] Generating HTML report...")
    combined = {
        "quality_score":      quality["total_score"],
        "quality_label":      label,
        "skill_match_score":  match["skill_match_score"],
        "tfidf_score":        match["tfidf_score"],
        "final_match_score":  match["final_match_score"],
        "resume_skills":      resume_skills,
        "jd_skills":          jd_skills,
        "matched_skills":     match["matched_skills"],
        "missing_skills":     match["missing_skills"],
        "extra_skills":       match["extra_skills"],
        "skills_by_category": resume_skills_result["by_category"],
        "score_breakdown":    quality["breakdown"],
        "sections":           processed["sections"],
        "recommended_roles":  recommended,
        "suggestions":        suggestions,
    }
    report_path = generate_report(combined)
    assert os.path.exists(report_path), "Report file not found!"
    size = os.path.getsize(report_path)
    print(f"  ✓ Report: {report_path}")
    print(f"  ✓ Report size: {size:,} bytes")

    # ── Assertions ────────────────────────────────────────────────────────────
    assert 0 <= match["skill_match_score"] <= 100
    assert 0 <= match["tfidf_score"] <= 100
    assert 0 <= match["final_match_score"] <= 100
    assert 0 <= quality["total_score"] <= 100
    assert len(recommended) <= 3
    assert len(suggestions) >= 1
    assert size > 10000  # report should be substantial

    print("\n" + "="*60)
    print("  ✅  ALL END-TO-END CHECKS PASSED")
    print("="*60)
    print(f"\n  Open your report:  {report_path}\n")

    return report_path


if __name__ == "__main__":
    run()
