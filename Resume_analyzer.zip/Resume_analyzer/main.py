"""
main.py
-------
ResumeIQ — Intelligent Resume & Job Match Analyzer
Entry point. Orchestrates the full analysis pipeline.

Usage:
    python main.py
"""

import sys
import os
import textwrap

# ── Module imports ────────────────────────────────────────────────────────────
from resume_parser   import extract_resume_text
from text_processor  import process_text
from skill_extractor import extract_skills
from job_matcher     import analyse_match
from resume_scorer   import compute_resume_score, score_label
from role_recommender import recommend_roles
from suggestions     import generate_suggestions
from report_generator import generate_report


# ── Console helpers ───────────────────────────────────────────────────────────

WIDTH = 52

def divider(char="─"):
    print(char * WIDTH)

def header(title: str):
    divider("═")
    print(f"{'ResumeIQ':^{WIDTH}}")
    print(f"{'Intelligent Resume & Job Match Analyzer':^{WIDTH}}")
    divider("═")

def step(n: int, total: int, msg: str):
    print(f"  [{n}/{total}] {msg}...")

def section(title: str):
    print()
    divider()
    print(f"  {title}")
    divider()


# ── Input helpers ─────────────────────────────────────────────────────────────

def get_pdf_path() -> str:
    """Prompt user for a PDF path until a valid one is given or they quit."""
    while True:
        print("\n  Enter the path to your resume PDF")
        print("  (or type 'q' to quit):")
        path = input("  > ").strip()
        if path.lower() == "q":
            print("  Goodbye!")
            sys.exit(0)
        if path:
            return path
        print("  ⚠  No path entered. Please try again.")


def get_job_description() -> str:
    """
    Prompt user to paste a job description.
    Supports multi-line input — press Enter twice (blank line) to finish,
    or enter a single line (most common use case).
    """
    print("\n  Paste the job description below.")
    print("  Press Enter twice when done (blank line = submit):")
    print()
    lines = []
    blank_count = 0
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line == "":
            blank_count += 1
            if blank_count >= 1 and lines:
                break
        else:
            blank_count = 0
            lines.append(line)

    jd = "\n".join(lines).strip()
    return jd


# ── Main pipeline ─────────────────────────────────────────────────────────────

def run_analysis(pdf_path: str, job_description: str) -> dict | None:
    """
    Execute the full analysis pipeline.

    Returns the combined analysis dict, or None on fatal error.
    """
    TOTAL_STEPS = 7

    # ── Step 1: Extract PDF text ─────────────────────────────────────────────
    step(1, TOTAL_STEPS, "Extracting resume text")
    parse_result = extract_resume_text(pdf_path)
    if not parse_result["success"]:
        print(f"\n  [ERR] Error: {parse_result['error']}")
        return None

    resume_raw = parse_result["text"]
    pages = parse_result["pages"]
    print(f"     [OK] Extracted text from {pages} page(s).")


    # ── Step 2: Process resume text ──────────────────────────────────────────
    step(2, TOTAL_STEPS, "Processing resume text")
    resume_processed = process_text(resume_raw)
    print(f"     [OK] {len(resume_processed['tokens'])} meaningful tokens found.")

    # ── Step 3: Extract skills from resume ───────────────────────────────────
    step(3, TOTAL_STEPS, "Extracting skills from resume")
    resume_skills_result = extract_skills(resume_raw)
    resume_skills = resume_skills_result["all_skills"]
    print(f"     [OK] {resume_skills_result['total']} skills detected.")

    # ── Step 4: Analyse job description ─────────────────────────────────────
    step(4, TOTAL_STEPS, "Analysing job description")
    if not job_description.strip():
        print("\n  [ERR] Error: Job description is empty.")
        return None
    jd_processed = process_text(job_description)
    jd_skills_result = extract_skills(job_description)
    jd_skills = jd_skills_result["all_skills"]
    print(f"     [OK] {jd_skills_result['total']} required skills identified in JD.")

    # ── Step 5: Calculate match scores ───────────────────────────────────────
    step(5, TOTAL_STEPS, "Calculating match scores")
    match_result = analyse_match(
        resume_skills=resume_skills,
        jd_skills=jd_skills,
        resume_text=resume_processed["cleaned_text"],
        jd_text=jd_processed["cleaned_text"],
    )
    print(
        f"     [OK] Skill Match: {match_result['skill_match_score']:.0f}%  |  "
        f"TF-IDF: {match_result['tfidf_score']:.0f}%  |  "
        f"Final: {match_result['final_match_score']}%"
    )

    # ── Step 6: Resume quality + roles + suggestions ─────────────────────────
    step(6, TOTAL_STEPS, "Generating quality score, roles & suggestions")
    sections = resume_processed["sections"]
    quality_result = compute_resume_score(sections)
    q_label = score_label(quality_result["total_score"])

    recommended = recommend_roles(resume_skills, top_n=3)

    suggestions = generate_suggestions(
        sections=sections,
        missing_skills=match_result["missing_skills"],
        score_breakdown=quality_result["breakdown"],
        resume_text=resume_raw,
    )
    print(f"     [OK] Quality: {quality_result['total_score']}/100  |  {len(recommended)} roles recommended.")

    # ── Step 7: Generate HTML report ─────────────────────────────────────────
    step(7, TOTAL_STEPS, "Generating HTML report")

    combined = {
        # Scores
        "quality_score":      quality_result["total_score"],
        "quality_label":      q_label,
        "skill_match_score":  match_result["skill_match_score"],
        "tfidf_score":        match_result["tfidf_score"],
        "final_match_score":  match_result["final_match_score"],
        # Skills
        "resume_skills":      resume_skills,
        "jd_skills":          jd_skills,
        "matched_skills":     match_result["matched_skills"],
        "missing_skills":     match_result["missing_skills"],
        "extra_skills":       match_result["extra_skills"],
        "skills_by_category": resume_skills_result["by_category"],
        # Quality breakdown
        "score_breakdown":    quality_result["breakdown"],
        "sections":           sections,
        # Roles & suggestions
        "recommended_roles":  recommended,
        "suggestions":        suggestions,
    }

    report_path = generate_report(combined)
    print(f"     [OK] Report saved to: {report_path}")

    return {**combined, "report_path": report_path}


# ── Display results ───────────────────────────────────────────────────────────

def display_results(result: dict):
    """Print a clean summary to the console."""

    section("RESULTS")

    print(f"\n  Resume Quality Score  : {result['quality_score']}/100 ({result['quality_label']})")
    print(f"  Skill Match Score     : {result['skill_match_score']:.0f}%")
    print(f"  TF-IDF Similarity     : {result['tfidf_score']:.0f}%")
    print(f"  Final Job Match       : {result['final_match_score']}%")

    # Matched skills
    print()
    if result["matched_skills"]:
        print(f"  Matched Skills ({len(result['matched_skills'])}):")
        for s in result["matched_skills"]:
            print(f"    [+] {s}")
    else:
        print("  Matched Skills: None found.")

    # Missing skills
    print()
    if result["missing_skills"]:
        print(f"  Missing Skills ({len(result['missing_skills'])}):")
        for s in result["missing_skills"][:10]:   # cap display at 10
            print(f"    [-] {s}")
        if len(result["missing_skills"]) > 10:
            print(f"    ... and {len(result['missing_skills'])-10} more.")
    else:
        print("  Missing Skills: None - great match!")

    # Recommended roles
    print()
    if result["recommended_roles"]:
        print("  Recommended Roles:")
        for i, role in enumerate(result["recommended_roles"], 1):
            print(f"    {i}. {role['role']}  —  {role['score']:.0f}%")
    else:
        print("  Recommended Roles: No matches found.")

    # Suggestions (top 3)
    print()
    if result["suggestions"]:
        print("  Top Suggestions:")
        for sug in result["suggestions"][:3]:
            wrapped = textwrap.fill(sug, width=62,
                                    initial_indent="    • ",
                                    subsequent_indent="      ")
            print(wrapped)

    # Report path
    print()
    divider()
    print(f"  Report : {result.get('report_path', 'N/A')}")
    divider()
    print()


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    header("ResumeIQ")
    print()

    # ── Get PDF path ─────────────────────────────────────────────────────────
    pdf_path = get_pdf_path()

    # ── Get job description ───────────────────────────────────────────────────
    job_description = get_job_description()
    if not job_description.strip():
        print("\n  ✗ No job description provided. Exiting.")
        sys.exit(1)

    # ── Run analysis ──────────────────────────────────────────────────────────
    print()
    divider()
    print(f"{'ANALYSIS IN PROGRESS':^{WIDTH}}")
    divider()
    print()

    result = run_analysis(pdf_path, job_description)
    if result is None:
        print("\n  Analysis failed. Please fix the errors above and try again.")
        sys.exit(1)

    display_results(result)


if __name__ == "__main__":
    main()
