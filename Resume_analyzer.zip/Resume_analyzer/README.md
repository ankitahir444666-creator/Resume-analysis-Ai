# ResumeIQ — Intelligent Resume & Job Match Analyzer

> A portfolio-ready Python + NLP + ML project that analyses a candidate's PDF
> resume against a job description and produces a detailed, explainable report.

---

## Problem Statement

Students and fresh graduates often struggle to understand why their resume
doesn't get shortlisted for a specific job. They lack tools to:

- See which required skills are missing from their resume.
- Understand how well their overall profile matches a job description.
- Get specific, actionable feedback on how to improve their resume.

**ResumeIQ** solves this by providing an offline, local, privacy-safe analysis
that requires no internet connection, no paid API, and no database.

---

## Features

| Feature | Description |
|---------|-------------|
| 📄 PDF Parsing | Extracts text from resume PDFs using `pdfplumber` |
| 🧹 Text Preprocessing | Cleans and normalises text using NLTK |
| 🛠 Skill Extraction | Detects 150+ skills across 9 categories |
| 🎯 Skill Match Score | Compares resume skills vs. job-required skills |
| 🤖 TF-IDF Similarity | NLP-based text similarity (cosine similarity) |
| 📊 Final Job Match | Weighted combination of skill + TF-IDF scores |
| 📋 Resume Quality Score | Heuristic section-based scoring (0-100) |
| 💼 Role Recommendation | Suggests top 3 matching job roles |
| 💡 Suggestions | Actionable, rule-based improvement tips |
| 📑 HTML Report | Professional dark-themed report with charts |

---

## Tech Stack

| Technology | Purpose |
|------------|---------|
| **Python 3** | Core application language |
| **pdfplumber** | PDF text extraction |
| **NLTK** | Text tokenisation and stopword removal |
| **scikit-learn** | TF-IDF vectorisation, cosine similarity |
| **NumPy** | Numerical operations |
| **Pandas** | (available for data extensions) |
| **HTML + CSS** | Report generation — no framework used |

---

## Architecture

```
ResumeIQ/
│
├── main.py              ← Entry point. Orchestrates the pipeline.
├── resume_parser.py     ← PDF text extraction (pdfplumber)
├── text_processor.py    ← Text cleaning, tokenisation, section detection
├── skill_extractor.py   ← Regex-based skill detection from JSON dictionary
├── job_matcher.py       ← Skill matching, TF-IDF similarity, final score
├── resume_scorer.py     ← Heuristic resume quality scoring
├── role_recommender.py  ← Top-N role recommendation by skill overlap
├── suggestions.py       ← Rule-based improvement suggestions
├── report_generator.py  ← HTML report generation
│
├── data/
│   ├── skills.json      ← Skill dictionary (9 categories, 150+ skills)
│   └── roles.json       ← Role definitions with required skills
│
├── sample_resumes/      ← Sample PDFs + job descriptions for testing
├── reports/             ← Generated HTML reports (auto-created)
├── tests/               ← Unit tests
│
├── requirements.txt
└── README.md
```

---

## How It Works — Processing Pipeline

```
[1] PDF Input
     ↓
[2] pdfplumber → Raw Text Extraction
     ↓
[3] NLTK → Clean + Tokenise Text | Section Detection (on original text)
     ↓
[4] Skill Dictionary (skills.json) → Word-Boundary Regex Matching
     ↓  ↘
     Resume Skills    JD Skills
            ↓
[5] Skill Match = matched / total_required × 100
[6] TF-IDF + Cosine Similarity (resume_text vs jd_text)
[7] Final Match = Skill × 60% + TF-IDF × 40%
     ↓
[8] Resume Quality Score (section presence heuristic)
[9] Role Recommendation (roles.json skill overlap)
[10] Suggestions (rule engine)
     ↓
[11] HTML Report → reports/resume_analysis.html
```

---

## ML/NLP Concepts Used

### 1. Text Preprocessing
- **Lowercasing**: Normalises text for case-insensitive matching.
- **Regex cleaning**: Removes URLs, emails, and special characters.
- **Tokenisation**: Splits text into words using NLTK's `word_tokenize`.
- **Stopword removal**: Removes common words (the, is, and) that carry no meaning for matching.

### 2. Skill Extraction
Skills are matched using **word-boundary regular expressions** (`\bSkill\b`) against
the skill dictionary. This prevents false positives (e.g., matching "R" inside "Research").
Matching is case-insensitive.

### 3. TF-IDF (Term Frequency – Inverse Document Frequency)
- **TF**: How often a word appears in a document.
- **IDF**: How rare the word is across all documents (rarer = more important).
- Together, TF-IDF weights words by their relevance to a specific document.
- We use scikit-learn's `TfidfVectorizer` with bigrams and sublinear TF normalisation.

### 4. Cosine Similarity
After TF-IDF converts the resume and JD into numeric vectors, cosine similarity
measures the **angle** between them.
- 1.0 = identical direction (same content)
- 0.0 = perpendicular (completely different content)
- This is a standard **NLP text similarity technique**, NOT deep learning.

### 5. Heuristic Resume Quality Score
A rule-based scoring system that checks whether key resume sections are present.
Each section contributes a fixed number of points.

---

## Scoring Method

### Skill Match Score
```
skill_match = (matched_skills / total_required_skills) × 100
```

### TF-IDF Similarity
```
tfidf_sim = cosine_similarity(tfidf_vector(resume), tfidf_vector(jd)) × 100
```

### Final Job Match Score (Weighted)
```
final_match = (skill_match × 0.60) + (tfidf_sim × 0.40)
```

*Skill match gets 60% weight because precise skill overlap is a stronger
hiring signal than general textual similarity.*

### Resume Quality Score
```
Contact Information      10 pts
Education                10 pts
Skills Section           15 pts
Projects                 15 pts
Work/Internship Exp.     15 pts
Certifications           10 pts
GitHub Profile           10 pts
LinkedIn Profile         10 pts
Achievements              5 pts
─────────────────────────────────
Total                   100 pts
```

> ⚠️ **Disclaimer**: The Resume Quality Score is a project-defined heuristic.
> It is NOT an official ATS (Applicant Tracking System) score or certification.
> It serves as an educational guide to improve resume completeness.

---

## Installation

### 1. Clone or download the project

```bash
cd ResumeIQ
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac / Linux
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Download NLTK data (automatic on first run)
The application downloads required NLTK data (`punkt`, `stopwords`) automatically
on the first run. No manual step is needed.

### 5. (Optional) Create sample PDFs for testing

```bash
pip install reportlab
python sample_resumes/create_sample_pdf.py
```

---

## Usage

```bash
python main.py
```

You will be prompted to:
1. Enter the path to your resume PDF.
2. Paste the job description.

The application runs the full analysis and:
- Displays results in the terminal.
- Generates an HTML report in `reports/`.

### Example Run

```
════════════════════════════════════════════════════════
                        ResumeIQ
              Intelligent Resume & Job Match Analyzer
════════════════════════════════════════════════════════

  Enter the path to your resume PDF
  > sample_resumes/sample_data_analyst.pdf

  Paste the job description below.
  Press Enter twice when done:

  > (paste job description, then press Enter twice)

──────────────────────────────────────────────────────
                 ANALYSIS IN PROGRESS
──────────────────────────────────────────────────────

  [1/7] Extracting resume text...
     ✓ Extracted text from 1 page(s).
  [2/7] Processing resume text...
     ✓ 124 meaningful tokens found.
  [3/7] Extracting skills from resume...
     ✓ 14 skills detected.
  [4/7] Analysing job description...
     ✓ 11 required skills identified in JD.
  [5/7] Calculating match scores...
     ✓ Skill Match: 72%  |  TF-IDF: 64%  |  Final: 69%
  [6/7] Generating quality score, roles & suggestions...
     ✓ Quality: 85/100  |  3 roles recommended.
  [7/7] Generating HTML report...
     ✓ Report saved to: reports/resume_analysis_20240729_143022.html

──────────────────────────────────────────────────────
                       RESULTS
──────────────────────────────────────────────────────

  Resume Quality Score  : 85/100 (Excellent)
  Skill Match Score     : 72%
  TF-IDF Similarity     : 64%
  Final Job Match       : 69%

  Matched Skills (8):
    ✓ Python
    ✓ Pandas
    ✓ NumPy
    ✓ SQL
    ✓ Matplotlib
    ✓ Git
    ✓ Statistics
    ✓ Data Analysis

  Missing Skills (3):
    ✗ Power BI
    ✗ Tableau
    ✗ Excel

  Recommended Roles:
    1. Data Analyst  —  71%
    2. Machine Learning Intern  —  58%
    3. Python Developer  —  50%
```

---

## Project Structure

| File | Purpose |
|------|---------|
| `main.py` | CLI entry point, orchestrates the full pipeline |
| `resume_parser.py` | PDF text extraction and validation |
| `text_processor.py` | Cleaning, tokenisation, section detection |
| `skill_extractor.py` | Regex-based skill matching against JSON dictionary |
| `job_matcher.py` | Skill matching, TF-IDF, final score computation |
| `resume_scorer.py` | Heuristic quality scoring by section presence |
| `role_recommender.py` | Skill-based role recommendation engine |
| `suggestions.py` | Rule-based actionable improvement suggestions |
| `report_generator.py` | HTML report creation |
| `data/skills.json` | Extensible skill dictionary (9 categories) |
| `data/roles.json` | Role definitions with required skill lists |
| `tests/test_all.py` | Unit tests for all modules |

---

## Running Tests

```bash
# Run all tests
python tests/test_all.py

# Or with pytest (if installed)
pip install pytest
pytest tests/ -v
```

---

## Limitations

1. **Image-only PDFs**: If the PDF is a scan/image, no text can be extracted. The app will display a clear error message. OCR support is not included.
2. **Informal skill mentions**: Skills buried in paragraphs without clear labelling may not always be detected.
3. **Heuristic scoring**: The Resume Quality Score is based on keyword/pattern matching — not semantic understanding.
4. **Fixed skill dictionary**: Skills not in `data/skills.json` are not detected. The JSON file is easy to extend.
5. **Single-language**: Analysis works best for English-language resumes and job descriptions.

---

## Future Improvements

These are ideas for extending the project — **not implemented** in this version:

- **Better NLP**: Use spaCy's Named Entity Recognition for more accurate skill extraction.
- **Semantic embeddings**: Use sentence-transformers for deeper semantic similarity.
- **Trained role classifier**: Use a trained ML model instead of skill-overlap heuristics.
- **OCR support**: Add Tesseract OCR for image-based PDFs.
- **Web interface**: Flask or Streamlit UI for non-technical users.
- **History & database**: Store past analyses for trend tracking.
- **Multi-language support**: Extend preprocessing and dictionaries for other languages.

---

## Disclaimer

ResumeIQ is an educational project for learning Python, NLP, and ML concepts.
It is not a professional recruitment tool or certified ATS system.

The scoring formulas, weights, and heuristics are project-defined and are meant
to be explainable and understandable, not industry-standard metrics.

---

*Built with Python · NLTK · scikit-learn · pdfplumber · No AI APIs · No cloud*
