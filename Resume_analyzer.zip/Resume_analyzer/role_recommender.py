"""
role_recommender.py
-------------------
Recommends the top-N job roles based on a candidate's detected skills.

Strategy
--------
For each role in data/roles.json:
  - Count how many of the role's required skills the candidate has.
  - Compute  match% = matched_skills / total_role_skills * 100
  - Return the top-N roles sorted by match% descending.
"""

import json
import os

_ROLES_FILE = os.path.join(os.path.dirname(__file__), "data", "roles.json")
_roles_db: dict | None = None


def _load_roles() -> dict:
    """Load roles from JSON file. Returns an empty dict on failure."""
    global _roles_db
    if _roles_db is not None:
        return _roles_db

    if not os.path.exists(_ROLES_FILE):
        print(f"  Warning: Roles file not found at '{_ROLES_FILE}'.")
        _roles_db = {}
        return _roles_db

    try:
        with open(_ROLES_FILE, "r", encoding="utf-8") as f:
            _roles_db = json.load(f)
    except json.JSONDecodeError as e:
        print(f"  Warning: roles.json is malformed – {e}")
        _roles_db = {}
    except Exception as e:
        print(f"  Warning: Could not load roles.json – {e}")
        _roles_db = {}

    return _roles_db


def recommend_roles(candidate_skills: list[str], top_n: int = 3) -> list[dict]:
    """
    Recommend the best-matching roles for the candidate.

    Parameters
    ----------
    candidate_skills : list[str]
        All skills detected in the resume.
    top_n : int
        Number of top roles to return (default 3).

    Returns
    -------
    list of dicts, each with:
        role         (str)         – role name
        score        (float)       – match percentage 0-100
        matched      (list[str])   – skills the candidate has for this role
        total_needed (int)         – total skills required for this role
        description  (str)         – short role description
    """
    roles_db = _load_roles()

    if not roles_db:
        return []

    candidate_lower = {s.lower() for s in candidate_skills}
    results = []

    for role_name, role_data in roles_db.items():
        role_skills = role_data.get("skills", [])
        description = role_data.get("description", "")

        if not role_skills:
            continue

        matched = [s for s in role_skills if s.lower() in candidate_lower]
        score = round(len(matched) / len(role_skills) * 100, 1)

        results.append({
            "role": role_name,
            "score": score,
            "matched": matched,
            "total_needed": len(role_skills),
            "description": description,
        })

    # Sort by score descending, then alphabetically for ties
    results.sort(key=lambda x: (-x["score"], x["role"]))

    return results[:top_n]
