# WHAT IS ResumeIQ & HOW IT WORKS
### Intelligent Resume & Job Match Analyzer

---

## THE REAL-WORLD PROBLEM

Imagine you apply for a Data Analyst job on LinkedIn.
You send your resume. You hear nothing back.

Why? Maybe because:
- Your resume is missing keywords the company is looking for
- Your resume doesn't mention SQL or Power BI, which the job requires
- Your resume has no GitHub link, no certifications, no projects section
- A recruiter glances at it for 6 seconds and moves on

You have no way of knowing any of this.

**ResumeIQ solves this problem.** It reads your resume, reads the job description,
and tells you exactly how well they match — and what you should fix.

---

## WHAT THIS PROJECT DOES (IN PLAIN ENGLISH)

You give the app two things:
1. Your resume (as a PDF)
2. A job description (pasted as text)

The app then does **10 things automatically:**

1. Reads your PDF and extracts all the text from it
2. Cleans and processes the text (removes junk, normalises it)
3. Detects which skills are present in your resume (Python, SQL, Git, etc.)
4. Detects which skills the job description requires
5. Finds out which required skills you have (**matched skills**)
6. Finds out which required skills you're missing (**missing skills**)
7. Calculates a **Skill Match Score** (how many required skills you have)
8. Calculates a **Text Similarity Score** using a technique called TF-IDF
9. Gives your resume a **Quality Score** (checks if you have sections like Projects, GitHub, LinkedIn, etc.)
10. Recommends which job roles suit your profile best

Finally, it generates a **professional HTML report** with everything explained visually.

---

## THE OUTPUT AT A GLANCE

After running the app, you get:

| Output | What it tells you |
|--------|-------------------|
| **Resume Quality Score** | How complete and well-structured your resume is (out of 100) |
| **Skill Match Score** | What % of the job's required skills your resume covers |
| **TF-IDF Similarity** | How similar your resume text is to the job description text |
| **Final Job Match** | A single combined score showing overall fit for the role |
| **Matched Skills** | Skills you already have that the job wants |
| **Missing Skills** | Skills the job wants that you don't have on your resume |
| **Recommended Roles** | Top 3 job roles that suit your current skill set |
| **Suggestions** | Specific things to add or improve on your resume |

---

## HOW EACH SCORE IS CALCULATED

### 1. Skill Match Score

The app has a dictionary of 150+ skills (Python, SQL, Git, Machine Learning, etc.)
organised into 9 categories.

It scans your resume for each skill using **word-matching** (not guessing — exact match).
It does the same for the job description.

Then it calculates:

```
Skill Match % = (Skills you have that the job requires) / (Total skills the job requires) × 100
```

**Example:**
- Job requires: Python, Pandas, SQL, Git, Flask (5 skills)
- You have: Python, Pandas, Git (3 skills)
- Skill Match = 3 / 5 × 100 = **60%**

---

### 2. TF-IDF Similarity Score

This is the machine learning / NLP part of the project.

**TF-IDF** stands for **Term Frequency – Inverse Document Frequency**.
It's a standard technique used in search engines and document comparison.

Here's the simple explanation:
- It converts your resume into a list of numbers (a "vector") based on which words appear and how importantly
- It does the same for the job description
- It then calculates **cosine similarity** — how similar these two number-lists are
- A score of 100% means identical text, 0% means nothing in common

This captures **context** — not just skills, but the overall language and themes of your resume vs. the job.

> This is NOT AI or machine learning in the buzzword sense. It's a deterministic mathematical technique that has existed for decades. It's honest, explainable, and works well.

---

### 3. Final Job Match Score

The two scores are combined with weights:

```
Final Match = (Skill Match × 60%) + (TF-IDF Similarity × 40%)
```

Skill match gets more weight because specific skill overlap is the strongest signal
of whether a person is suitable for a job — more than general text similarity.

**Example:**
- Skill Match = 70%
- TF-IDF = 55%
- Final = (70 × 0.6) + (55 × 0.4) = 42 + 22 = **64%**

---

### 4. Resume Quality Score

The app checks whether your resume contains these important sections:

| Section | Points |
|---------|--------|
| Contact Information (email, phone) | 10 |
| Education | 10 |
| Skills section | 15 |
| Projects | 15 |
| Work / Internship Experience | 15 |
| Certifications | 10 |
| GitHub profile link | 10 |
| LinkedIn profile link | 10 |
| Achievements / Awards | 5 |
| **Total** | **100** |

Each section is detected by looking for specific keywords in your resume.
For example, "github.com" → GitHub detected. "B.Tech" → Education detected.

> **Important:** This is NOT an official ATS score. It is a project-defined
> heuristic (a smart rule-based system). It's designed to guide you,
> not to certify your resume officially.

---

### 5. Role Recommendation

The app has a database of 10 job roles (Data Analyst, ML Intern, Python Developer, etc.)
Each role has a list of required skills.

For each role, it calculates:
```
Role Match % = (Your skills that overlap with the role) / (Total skills needed for the role) × 100
```

The top 3 roles by score are shown.

---

## HOW THE APP PROCESSES TEXT (STEP BY STEP)

Here is exactly what happens under the hood when you run the app:

```
Your PDF Resume
      │
      ▼
[pdfplumber] — opens the PDF and extracts raw text from every page
      │
      ▼
[NLTK] — cleans the text:
         - converts to lowercase
         - removes website links and email addresses
         - removes special characters
         - splits text into individual words (tokenisation)
         - removes "stopwords" (common words like: the, is, and, of)
         │
         ├──► Original text kept → used for section detection
         └──► Cleaned text → used for TF-IDF and skill matching
      │
      ▼
[Skill Extractor] — scans text for 150+ skills using word-boundary matching
                    (word-boundary means it won't match "R" inside "Research")
      │
      ▼
Same process for the Job Description text
      │
      ▼
[Job Matcher]
  ├── Compares resume skills vs. JD skills → Matched / Missing lists
  ├── Calculates Skill Match %
  ├── Runs TF-IDF on full texts → Similarity score
  └── Combines into Final Match Score
      │
      ▼
[Resume Scorer] — checks for section keywords in original text → Quality Score
      │
      ▼
[Role Recommender] — matches your skills against each role's requirements
      │
      ▼
[Suggestion Engine] — rule-based tips based on what's missing
      │
      ▼
[Report Generator] — builds the HTML report with everything visualised
      │
      ▼
  reports/resume_analysis_TIMESTAMP.html
```

---

## WHAT SKILLS CAN IT DETECT?

The skills dictionary (`data/skills.json`) contains 150+ skills in 9 categories:

| Category | Example Skills |
|----------|---------------|
| Programming | Python, Java, C++, JavaScript, Dart, Go |
| Data | Pandas, NumPy, Excel, SQL, Power BI, Tableau |
| Machine Learning | Scikit-learn, TensorFlow, PyTorch, NLP, Deep Learning |
| Web | HTML, CSS, React, Flask, Django, FastAPI |
| Mobile | Flutter, Dart, Android, Kotlin |
| Database | MySQL, PostgreSQL, MongoDB, SQLite |
| Tools | Git, GitHub, Docker, VS Code, Jupyter |
| Cloud | AWS, Azure, Google Cloud, CI/CD |
| Soft Skills | Communication, Leadership, Teamwork |

You can add more skills at any time by editing `data/skills.json`.

---

## WHAT JOB ROLES CAN IT RECOMMEND?

The roles database (`data/roles.json`) includes:

1. Python Developer
2. Data Analyst
3. Machine Learning Intern
4. Data Scientist Intern
5. Backend Developer
6. Flutter Developer
7. Software Developer
8. Web Developer
9. Data Engineer
10. DevOps Engineer

You can add more roles by editing `data/roles.json`.

---

## WHAT ARE THE LIMITATIONS?

Being honest about what this project can and cannot do:

| Limitation | Explanation |
|-----------|-------------|
| **Scanned PDFs don't work** | If your PDF is a photo/scan of a resume, the app can't read it. Use a PDF created digitally (from Word, Google Docs, etc.) |
| **Only English** | The skill detection and text processing are designed for English |
| **Exact skill matching** | "Machine Learning" is detected but "ML" might not be (unless added to the dictionary) |
| **Not an official ATS** | Real company ATS systems are much more complex — this is an educational tool |
| **Short job descriptions** | If the JD is only 1-2 sentences, the TF-IDF score may be low because there isn't much text to compare |

---

## TECHNOLOGIES USED (AND WHY)

| Technology | Why it was used |
|------------|----------------|
| **Python** | Simple, readable, widely used for data and ML projects |
| **pdfplumber** | Best Python library for extracting text from PDFs |
| **NLTK** | Industry-standard NLP toolkit for tokenisation and stopwords |
| **scikit-learn** | Provides TF-IDF and cosine similarity — clean, well-documented |
| **NumPy** | Fast numerical operations for vector math |
| **HTML + CSS** | Generates the report without any framework dependencies |

No paid APIs. No internet needed after setup. No database. No cloud.
Everything runs 100% locally on your computer.

---

## WHO IS THIS PROJECT FOR?

This project is designed for:
- **Students** learning Python, NLP, and ML who want a real portfolio project
- **Job seekers** who want quick feedback on how well their resume matches a specific role
- **Anyone** who wants to understand what skills they're missing for a target job

It's honest, explainable, and educational — not a black-box AI tool.

---

*Built with Python · NLTK · scikit-learn · pdfplumber · No AI APIs · No cloud*
