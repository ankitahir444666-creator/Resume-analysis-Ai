"""
suggestions.py
--------------
Generates actionable, rule-based improvement suggestions for the resume.

All suggestions are deterministic — based on what sections were detected,
what skills are missing, and other simple heuristics.

This is NOT AI-generated advice. It is a structured rule engine.
"""


def generate_suggestions(
    sections: dict[str, bool],
    missing_skills: list[str],
    score_breakdown: list[dict],
    resume_text: str = "",
) -> list[str]:
    """
    Generate a list of specific, actionable resume improvement suggestions.

    Parameters
    ----------
    sections        : dict[str, bool]  – output from detect_sections()
    missing_skills  : list[str]        – skills required by JD but absent in resume
    score_breakdown : list[dict]       – breakdown from compute_resume_score()
    resume_text     : str              – raw resume text (for additional checks)

    Returns
    -------
    list[str] – ordered list of suggestion strings
    """
    suggestions: list[str] = []
    text_lower = resume_text.lower() if resume_text else ""

    # ── Section-based suggestions ────────────────────────────────────────────

    if not sections.get("contact"):
        suggestions.append(
            "Add clear contact information (email, phone number) at the top of your resume."
        )

    if not sections.get("education"):
        suggestions.append(
            "Include an Education section listing your degree, institution, and year of graduation."
        )

    if not sections.get("skills"):
        suggestions.append(
            "Add a dedicated Skills section that clearly lists your technical skills. "
            "Recruiters often scan this section first."
        )

    if not sections.get("projects"):
        suggestions.append(
            "Add a Projects section with 2–3 relevant projects. "
            "For each project, describe: what it does, technologies used, and the outcome."
        )

    if not sections.get("experience"):
        suggestions.append(
            "If you have internship, freelance, research, or practical experience, "
            "add it clearly under an Experience section with dates and responsibilities."
        )

    if not sections.get("certifications"):
        suggestions.append(
            "Consider adding relevant online certifications (e.g., from Coursera, Udemy, edX, or Google). "
            "Even short courses demonstrate initiative."
        )

    if not sections.get("github"):
        suggestions.append(
            "Add a link to your GitHub profile. Recruiters in tech almost always check GitHub. "
            "Make sure your repositories are public and well-documented."
        )

    if not sections.get("linkedin"):
        suggestions.append(
            "Add your LinkedIn profile URL. A complete LinkedIn profile significantly "
            "improves your visibility to recruiters."
        )

    if not sections.get("achievements"):
        suggestions.append(
            "Add measurable achievements — e.g., 'Improved model accuracy from 78% to 91%' "
            "or 'Completed project 2 weeks ahead of schedule'. Quantified results stand out."
        )

    # ── Missing job skills suggestions ───────────────────────────────────────

    if missing_skills:
        if len(missing_skills) <= 5:
            skills_list = ", ".join(missing_skills)
            suggestions.append(
                f"The job requires these skills not found in your resume: {skills_list}. "
                "Consider learning them or explicitly mentioning them if you have any exposure."
            )
        else:
            top_missing = ", ".join(missing_skills[:5])
            suggestions.append(
                f"Several required skills are missing from your resume. "
                f"Key ones include: {top_missing} (and {len(missing_skills) - 5} more). "
                "Prioritise the most critical ones for the role."
            )

    # ── General quality suggestions ──────────────────────────────────────────

    # Very short resume text
    word_count = len(resume_text.split()) if resume_text else 0
    if word_count < 150:
        suggestions.append(
            f"Your resume appears to be very short (~{word_count} words). "
            "A well-developed resume for a student or recent graduate typically has 300–600 words."
        )
    elif word_count > 1200:
        suggestions.append(
            "Your resume may be too lengthy. For students and early-career professionals, "
            "aim for a single page (roughly 400–700 words in the extracted text)."
        )

    # Suggest quantifying project descriptions if projects present but no numbers
    if sections.get("projects") and not any(
        char.isdigit() for char in text_lower[:2000]
    ):
        suggestions.append(
            "Consider adding numbers and metrics to your project descriptions "
            "(e.g., dataset size, accuracy achieved, users served)."
        )

    # ── Final fallback ───────────────────────────────────────────────────────

    if not suggestions:
        suggestions.append(
            "Your resume looks comprehensive! "
            "Focus on tailoring your skills and project descriptions to match each job description."
        )

    return suggestions
