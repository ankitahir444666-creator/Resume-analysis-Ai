"""
resume_scorer.py
----------------
Computes a Resume Quality Score (0-100) using explainable heuristic rules.

This is NOT an official ATS score.
It is a project-defined heuristic used to evaluate how complete and
well-structured a resume appears based on section presence and basic signals.

Scoring breakdown
-----------------
  Contact Information    10 pts
  Education              10 pts
  Skills                 15 pts
  Projects               15 pts
  Experience             15 pts
  Certifications         10 pts
  GitHub                 10 pts
  LinkedIn               10 pts
  Achievements            5 pts
  ----------------------------------
  Total                 100 pts
"""

# Maximum points per category
_SCORE_WEIGHTS: dict[str, int] = {
    "contact":        10,
    "education":      10,
    "skills":         15,
    "projects":       15,
    "experience":     15,
    "certifications": 10,
    "github":         10,
    "linkedin":       10,
    "achievements":   5,
}

# Human-readable labels for each section key
_SECTION_LABELS: dict[str, str] = {
    "contact":        "Contact Information",
    "education":      "Education",
    "skills":         "Skills Section",
    "projects":       "Projects",
    "experience":     "Work / Internship Experience",
    "certifications": "Certifications",
    "github":         "GitHub Profile",
    "linkedin":       "LinkedIn Profile",
    "achievements":   "Achievements / Awards",
}


def compute_resume_score(sections: dict[str, bool]) -> dict:
    """
    Compute a heuristic quality score based on section detection results.

    Parameters
    ----------
    sections : dict[str, bool]
        Output from text_processor.detect_sections().

    Returns
    -------
    dict with:
        total_score  (int)              – overall score 0-100
        breakdown    (list[dict])       – per-section details
        feedback     (list[str])        – plain-text feedback per section
    """
    total = 0
    breakdown = []
    feedback = []

    for section_key, max_pts in _SCORE_WEIGHTS.items():
        found = sections.get(section_key, False)
        earned = max_pts if found else 0
        total += earned

        label = _SECTION_LABELS.get(section_key, section_key.title())
        breakdown.append({
            "section": label,
            "found": found,
            "earned": earned,
            "max": max_pts,
        })

        if not found:
            feedback.append(f"Missing: {label} ({max_pts} pts)")

    return {
        "total_score": int(total),
        "breakdown": breakdown,
        "feedback": feedback,
    }


def score_label(score: int) -> str:
    """Return a human-readable quality label for the score."""
    if score >= 85:
        return "Excellent"
    elif score >= 70:
        return "Good"
    elif score >= 50:
        return "Average"
    elif score >= 30:
        return "Needs Improvement"
    else:
        return "Poor"
