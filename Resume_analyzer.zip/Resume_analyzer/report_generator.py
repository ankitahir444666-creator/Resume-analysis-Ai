"""
report_generator.py
--------------------
Generates a clean, professional HTML report from the analysis results.
No external CSS frameworks are used — everything is plain HTML + CSS.
"""

import os
from datetime import datetime

_REPORTS_DIR = os.path.join(os.path.dirname(__file__), "reports")


def _score_color(score: float) -> str:
    """Return a CSS color class name based on score range."""
    if score >= 75:
        return "#27ae60"   # green
    elif score >= 50:
        return "#f39c12"   # amber
    elif score >= 30:
        return "#e67e22"   # orange
    else:
        return "#e74c3c"   # red


def _bar_html(label: str, score: float, max_score: float = 100) -> str:
    """Render a score bar row."""
    pct = min(max(score / max_score * 100, 0), 100)
    color = _score_color(score)
    return f"""
        <div class="score-row">
            <div class="score-label">{label}</div>
            <div class="bar-wrap">
                <div class="bar-fill" style="width:{pct:.1f}%; background:{color};"></div>
            </div>
            <div class="score-val" style="color:{color};">{score:.0f}%</div>
        </div>"""


def _skill_badge(skill: str, css_class: str = "badge") -> str:
    return f'<span class="{css_class}">{skill}</span>'


def generate_report(analysis: dict, output_path: str | None = None) -> str:
    """
    Generate an HTML report and write it to disk.

    Parameters
    ----------
    analysis : dict
        The combined analysis result dict from main.py.
    output_path : str | None
        Override the default output path.

    Returns
    -------
    str – absolute path of the generated HTML file.
    """
    os.makedirs(_REPORTS_DIR, exist_ok=True)

    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(_REPORTS_DIR, f"resume_analysis_{timestamp}.html")

    # ── Unpack analysis ──────────────────────────────────────────────────────
    quality_score   = analysis.get("quality_score", 0)
    quality_label   = analysis.get("quality_label", "")
    skill_match     = analysis.get("skill_match_score", 0)
    tfidf_score     = analysis.get("tfidf_score", 0)
    final_score     = analysis.get("final_match_score", 0)
    matched_skills  = analysis.get("matched_skills", [])
    missing_skills  = analysis.get("missing_skills", [])
    extra_skills    = analysis.get("extra_skills", [])
    skills_by_cat   = analysis.get("skills_by_category", {})
    score_breakdown = analysis.get("score_breakdown", [])
    recommended     = analysis.get("recommended_roles", [])
    suggestions     = analysis.get("suggestions", [])
    now_str         = datetime.now().strftime("%d %B %Y, %I:%M %p")

    # ── Build HTML sections ──────────────────────────────────────────────────

    # Score bars
    bars_html = (
        _bar_html("Resume Quality", quality_score) +
        _bar_html("Final Job Match", final_score) +
        _bar_html("Skill Match", skill_match) +
        _bar_html("TF-IDF Similarity", tfidf_score)
    )

    # Big score circles
    def _circle(value, label, color):
        return f"""
        <div class="circle-wrap">
            <div class="circle" style="border-color:{color}; color:{color};">
                <span class="circle-num">{value}</span>
                <span class="circle-pct">%</span>
            </div>
            <div class="circle-label">{label}</div>
        </div>"""

    circles_html = (
        _circle(quality_score,   "Resume Quality",    _score_color(quality_score)) +
        _circle(final_score,     "Job Match",         _score_color(final_score)) +
        _circle(skill_match,     "Skill Match",       _score_color(skill_match)) +
        _circle(int(tfidf_score), "TF-IDF Similarity", _score_color(tfidf_score))
    )

    # Skills by category
    skills_cat_html = ""
    if skills_by_cat:
        for cat, skill_list in skills_by_cat.items():
            badges = " ".join(_skill_badge(s, "badge-blue") for s in skill_list)
            skills_cat_html += f"""
            <div class="cat-block">
                <h4 class="cat-title">{cat}</h4>
                <div class="badge-group">{badges}</div>
            </div>"""
    else:
        skills_cat_html = "<p class='empty-note'>No skills detected in the resume.</p>"

    # Matched / Missing
    matched_html = (
        " ".join(_skill_badge(s, "badge-green") for s in matched_skills)
        if matched_skills else "<p class='empty-note'>No matched skills found.</p>"
    )
    missing_html = (
        " ".join(_skill_badge(s, "badge-red") for s in missing_skills)
        if missing_skills else "<p class='empty-note'>No missing skills — great match!</p>"
    )

    # Score breakdown table
    breakdown_rows = ""
    for item in score_breakdown:
        status_icon = "✅" if item["found"] else "❌"
        row_class = "row-found" if item["found"] else "row-missing"
        breakdown_rows += f"""
            <tr class="{row_class}">
                <td>{status_icon}</td>
                <td>{item['section']}</td>
                <td>{item['earned']}/{item['max']} pts</td>
            </tr>"""

    # Recommended roles
    roles_html = ""
    for i, role in enumerate(recommended, 1):
        color = _score_color(role["score"])
        matched_role_badges = " ".join(_skill_badge(s, "badge-blue") for s in role["matched"][:6])
        more = f" <span class='more-note'>+{len(role['matched'])-6} more</span>" if len(role["matched"]) > 6 else ""
        roles_html += f"""
        <div class="role-card">
            <div class="role-rank">#{i}</div>
            <div class="role-info">
                <div class="role-name">{role['role']}</div>
                <div class="role-desc">{role.get('description', '')}</div>
                <div class="badge-group">{matched_role_badges}{more}</div>
            </div>
            <div class="role-score" style="color:{color};">{role['score']:.0f}%</div>
        </div>"""

    if not roles_html:
        roles_html = "<p class='empty-note'>No role recommendations available.</p>"

    # Suggestions
    suggestions_html = ""
    for sug in suggestions:
        suggestions_html += f'<li class="sug-item">{sug}</li>'
    if not suggestions_html:
        suggestions_html = "<li class='sug-item'>No suggestions — your resume looks good!</li>"

    # ── Full HTML ────────────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ResumeIQ — Analysis Report</title>
    <meta name="description" content="Intelligent resume and job match analysis report generated by ResumeIQ." />
    <style>
        /* ── Reset & Variables ─────────────────────────────────────────── */
        *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

        :root {{
            --bg:       #0f1117;
            --surface:  #1a1d27;
            --surface2: #21253a;
            --accent:   #6c63ff;
            --accent2:  #a78bfa;
            --text:     #e2e8f0;
            --muted:    #8892a4;
            --green:    #27ae60;
            --amber:    #f39c12;
            --red:      #e74c3c;
            --radius:   12px;
            --shadow:   0 4px 24px rgba(0,0,0,0.4);
        }}

        body {{
            background: var(--bg);
            color: var(--text);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            font-size: 15px;
            line-height: 1.65;
            min-height: 100vh;
        }}

        /* ── Top gradient banner ───────────────────────────────────────── */
        .hero {{
            background: linear-gradient(135deg, #1a1d27 0%, #12103a 50%, #1a1d27 100%);
            border-bottom: 1px solid rgba(108,99,255,0.25);
            padding: 48px 24px 36px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }}
        .hero::before {{
            content: '';
            position: absolute;
            width: 500px; height: 500px;
            background: radial-gradient(circle, rgba(108,99,255,0.15) 0%, transparent 70%);
            top: -100px; left: 50%; transform: translateX(-50%);
            pointer-events: none;
        }}
        .hero-logo {{
            font-size: 2.8rem;
            font-weight: 800;
            letter-spacing: -1px;
            background: linear-gradient(90deg, #6c63ff, #a78bfa, #818cf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }}
        .hero-sub {{
            color: var(--muted);
            margin-top: 6px;
            font-size: 1rem;
            letter-spacing: 0.5px;
        }}
        .hero-date {{
            color: var(--muted);
            font-size: 0.82rem;
            margin-top: 10px;
        }}

        /* ── Layout ───────────────────────────────────────────────────── */
        .container {{
            max-width: 960px;
            margin: 0 auto;
            padding: 32px 20px 64px;
        }}

        /* ── Section card ─────────────────────────────────────────────── */
        .card {{
            background: var(--surface);
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: var(--radius);
            padding: 28px 32px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
        }}
        .card-title {{
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--accent2);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .card-title::after {{
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255,255,255,0.07);
            margin-left: 8px;
        }}

        /* ── Score circles ────────────────────────────────────────────── */
        .circles-grid {{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 32px;
            padding: 8px 0;
        }}
        .circle-wrap {{
            text-align: center;
        }}
        .circle {{
            width: 110px;
            height: 110px;
            border-radius: 50%;
            border: 4px solid;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            background: var(--surface2);
            transition: transform 0.2s;
        }}
        .circle:hover {{ transform: scale(1.05); }}
        .circle-num {{
            font-size: 2rem;
            font-weight: 800;
            line-height: 1;
        }}
        .circle-pct {{
            font-size: 0.75rem;
            opacity: 0.7;
        }}
        .circle-label {{
            font-size: 0.78rem;
            color: var(--muted);
            max-width: 90px;
        }}

        /* ── Score bars ───────────────────────────────────────────────── */
        .score-row {{
            display: grid;
            grid-template-columns: 180px 1fr 60px;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }}
        .score-label {{
            font-size: 0.88rem;
            color: var(--muted);
        }}
        .bar-wrap {{
            background: rgba(255,255,255,0.07);
            border-radius: 99px;
            height: 10px;
            overflow: hidden;
        }}
        .bar-fill {{
            height: 100%;
            border-radius: 99px;
            transition: width 0.4s ease;
        }}
        .score-val {{
            font-size: 0.88rem;
            font-weight: 700;
            text-align: right;
        }}

        /* ── Badges ───────────────────────────────────────────────────── */
        .badge-group {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 8px;
        }}
        .badge {{
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.12);
            color: var(--text);
            padding: 4px 12px;
            border-radius: 99px;
            font-size: 0.82rem;
        }}
        .badge-blue  {{ background: rgba(108,99,255,0.18); border-color: rgba(108,99,255,0.4); color: #a78bfa; }}
        .badge-green {{ background: rgba(39,174,96,0.18);  border-color: rgba(39,174,96,0.4);  color: #4ade80; }}
        .badge-red   {{ background: rgba(231,76,60,0.18);  border-color: rgba(231,76,60,0.4);  color: #f87171; }}

        /* ── Category blocks ──────────────────────────────────────────── */
        .cat-block {{
            margin-bottom: 18px;
        }}
        .cat-title {{
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--muted);
            margin-bottom: 6px;
        }}

        /* ── Quality score table ──────────────────────────────────────── */
        .breakdown-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
        }}
        .breakdown-table th {{
            text-align: left;
            padding: 8px 12px;
            color: var(--muted);
            border-bottom: 1px solid rgba(255,255,255,0.07);
            font-weight: 600;
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .breakdown-table td {{
            padding: 9px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.04);
        }}
        .row-found  td:first-child {{ color: var(--green); }}
        .row-missing td:first-child {{ color: var(--red); }}
        .breakdown-table tr:last-child td {{ border-bottom: none; }}

        /* ── Role cards ───────────────────────────────────────────────── */
        .role-card {{
            display: flex;
            align-items: flex-start;
            gap: 16px;
            background: var(--surface2);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 10px;
            padding: 18px 20px;
            margin-bottom: 14px;
            transition: border-color 0.2s;
        }}
        .role-card:hover {{ border-color: rgba(108,99,255,0.4); }}
        .role-rank {{
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--accent);
            min-width: 36px;
        }}
        .role-info {{ flex: 1; }}
        .role-name  {{ font-weight: 700; font-size: 1rem; }}
        .role-desc  {{ color: var(--muted); font-size: 0.83rem; margin: 4px 0 10px; }}
        .role-score {{
            font-size: 1.6rem;
            font-weight: 800;
            min-width: 64px;
            text-align: right;
        }}
        .more-note {{ color: var(--muted); font-size: 0.78rem; }}

        /* ── Suggestions ──────────────────────────────────────────────── */
        .sug-list {{ list-style: none; padding: 0; }}
        .sug-item {{
            background: var(--surface2);
            border-left: 3px solid var(--accent);
            border-radius: 0 8px 8px 0;
            padding: 12px 16px;
            margin-bottom: 10px;
            font-size: 0.91rem;
            line-height: 1.55;
        }}

        /* ── Analysis details section ─────────────────────────────────── */
        .method-block {{
            background: var(--surface2);
            border-radius: 8px;
            padding: 14px 18px;
            margin-bottom: 12px;
            font-size: 0.88rem;
        }}
        .method-block h4 {{
            color: var(--accent2);
            font-size: 0.88rem;
            margin-bottom: 6px;
        }}
        .method-block p {{
            color: var(--muted);
            line-height: 1.6;
        }}
        code {{
            background: rgba(108,99,255,0.15);
            border-radius: 4px;
            padding: 1px 6px;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            color: #a78bfa;
        }}

        /* ── Footer ───────────────────────────────────────────────────── */
        .footer {{
            text-align: center;
            color: var(--muted);
            font-size: 0.78rem;
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.06);
            margin-top: 40px;
        }}

        /* ── Quality badge ────────────────────────────────────────────── */
        .quality-badge {{
            display: inline-block;
            padding: 4px 14px;
            border-radius: 99px;
            font-size: 0.82rem;
            font-weight: 700;
            margin-left: 10px;
            vertical-align: middle;
        }}

        .empty-note {{ color: var(--muted); font-style: italic; font-size: 0.88rem; }}

        @media (max-width: 600px) {{
            .score-row {{ grid-template-columns: 130px 1fr 48px; }}
            .circles-grid {{ gap: 20px; }}
            .circle {{ width: 88px; height: 88px; }}
            .circle-num {{ font-size: 1.6rem; }}
            .card {{ padding: 20px 16px; }}
        }}
    </style>
</head>
<body>

<!-- ── Header ────────────────────────────────────────────────────────────── -->
<div class="hero">
    <div class="hero-logo">⚡ ResumeIQ</div>
    <div class="hero-sub">Intelligent Resume &amp; Job Match Analyzer</div>
    <div class="hero-date">Report generated on {now_str}</div>
</div>

<div class="container">

    <!-- ── Score Overview ──────────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">📊 Score Overview</div>
        <div class="circles-grid">
            {circles_html}
        </div>
    </div>

    <!-- ── Score Bars ──────────────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">📈 Score Breakdown</div>
        {bars_html}
    </div>

    <!-- ── Matched & Missing Skills ────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">✅ Matched Skills</div>
        <div class="badge-group">{matched_html}</div>
    </div>

    <div class="card">
        <div class="card-title">❌ Missing Skills</div>
        <div class="badge-group">{missing_html}</div>
    </div>

    <!-- ── All Detected Skills ─────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">🛠️ Detected Resume Skills</div>
        {skills_cat_html}
    </div>

    <!-- ── Resume Quality Breakdown ────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">
            📋 Resume Quality Score — {quality_score}/100
            <span class="quality-badge"
                  style="background:rgba(108,99,255,0.2); color:#a78bfa;">
                {quality_label}
            </span>
        </div>
        <p style="color:var(--muted); font-size:0.82rem; margin-bottom:14px;">
            ⚠️ This is a project-defined heuristic score based on section presence.
            It is not an official ATS certification.
        </p>
        <table class="breakdown-table">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Section</th>
                    <th>Score</th>
                </tr>
            </thead>
            <tbody>
                {breakdown_rows}
            </tbody>
        </table>
    </div>

    <!-- ── Recommended Roles ───────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">🎯 Recommended Job Roles</div>
        {roles_html}
    </div>

    <!-- ── Suggestions ─────────────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">💡 Resume Improvement Suggestions</div>
        <ul class="sug-list">
            {suggestions_html}
        </ul>
    </div>

    <!-- ── How It Works ────────────────────────────────────────────────────── -->
    <div class="card">
        <div class="card-title">🔍 Analysis Methodology</div>

        <div class="method-block">
            <h4>Skill Detection</h4>
            <p>
                Skills are identified using a curated JSON dictionary of 150+ skills across 9 categories.
                Each skill is matched against the resume text using <strong>word-boundary regular expressions</strong>
                (case-insensitive). This prevents false positives (e.g., matching "R" inside every word).
            </p>
        </div>

        <div class="method-block">
            <h4>Skill Match Score</h4>
            <p>
                <code>Skill Match % = (Matched Skills ÷ Total Required Skills) × 100</code><br />
                Matched skills are those found in <em>both</em> the resume and the job description.
            </p>
        </div>

        <div class="method-block">
            <h4>TF-IDF + Cosine Similarity</h4>
            <p>
                TF-IDF (Term Frequency–Inverse Document Frequency) converts each text into a numeric vector
                where rare, important words get higher weight. Cosine similarity then measures the angle between
                the two vectors — a score of 1.0 means identical, 0 means no overlap.
                This is a standard <strong>NLP text similarity technique</strong>, not AI or machine learning.
            </p>
        </div>

        <div class="method-block">
            <h4>Final Job Match Score</h4>
            <p>
                <code>Final Match = (Skill Match × 60%) + (TF-IDF Similarity × 40%)</code><br />
                Skill match gets more weight because precise skill overlap is a stronger signal
                for hiring relevance than general text similarity.
            </p>
        </div>

        <div class="method-block">
            <h4>Resume Quality Score</h4>
            <p>
                Each major resume section (Education, Skills, Projects, etc.) is checked for
                presence using keyword/pattern matching on the original text.
                Points are awarded per section (total: 100 pts).
                Missing sections are highlighted as improvement opportunities.
            </p>
        </div>

        <div class="method-block">
            <h4>Role Recommendation</h4>
            <p>
                For each role in the roles database, we compute:
                <code>Role Match % = (Your Skills matching Role Skills) ÷ (Total Role Skills) × 100</code>.
                The top 3 roles by match percentage are recommended.
            </p>
        </div>
    </div>

</div><!-- /.container -->

<div class="footer">
    ResumeIQ — Intelligent Resume &amp; Job Match Analyzer &nbsp;|&nbsp;
    Built with Python · NLTK · scikit-learn · pdfplumber &nbsp;|&nbsp;
    No AI APIs used — all analysis is local and deterministic.
</div>

</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return os.path.abspath(output_path)
