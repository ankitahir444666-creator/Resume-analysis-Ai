"""
resume_parser.py
----------------
Extracts raw text from a PDF resume using pdfplumber.

This module handles:
- File existence validation
- PDF opening and reading
- Page-by-page text extraction
- Error handling for corrupt/empty PDFs
"""

import os
import pdfplumber


def extract_resume_text(pdf_path: str) -> dict:
    """
    Extract raw text from a PDF resume.

    Parameters
    ----------
    pdf_path : str
        Absolute or relative path to the PDF file.

    Returns
    -------
    dict with keys:
        success (bool)   - True if extraction succeeded
        text    (str)    - Combined text from all pages (empty string on failure)
        pages   (int)    - Number of pages processed
        error   (str)    - Error message if success is False
    """
    result = {
        "success": False,
        "text": "",
        "pages": 0,
        "error": ""
    }

    # ── 1. Validate path ────────────────────────────────────────────────────
    if not pdf_path or not pdf_path.strip():
        result["error"] = "No PDF path provided."
        return result

    pdf_path = pdf_path.strip().strip('"').strip("'")  # remove accidental quotes

    if not os.path.exists(pdf_path):
        result["error"] = f"File not found: '{pdf_path}'"
        return result

    if not pdf_path.lower().endswith(".pdf"):
        result["error"] = f"File does not appear to be a PDF: '{pdf_path}'"
        return result

    # ── 2. Open and extract ─────────────────────────────────────────────────
    try:
        with pdfplumber.open(pdf_path) as pdf:
            if len(pdf.pages) == 0:
                result["error"] = "PDF has no pages."
                return result

            page_texts = []
            for i, page in enumerate(pdf.pages):
                try:
                    text = page.extract_text()
                    if text:
                        page_texts.append(text)
                except Exception as page_err:
                    # Skip unreadable pages but don't abort entirely
                    print(f"  Warning: Could not read page {i + 1}: {page_err}")

            combined = "\n".join(page_texts).strip()

            if not combined:
                result["error"] = (
                    "No text could be extracted from the PDF. "
                    "It may be a scanned image-only PDF. "
                    "Please use a text-based PDF."
                )
                return result

            result["success"] = True
            result["text"] = combined
            result["pages"] = len(pdf.pages)

    except pdfplumber.pdfminer.pdfdocument.PDFPasswordIncorrect:
        result["error"] = "PDF is password-protected. Please remove the password and try again."
    except Exception as exc:
        result["error"] = f"Failed to read PDF: {exc}"

    return result
