# HOW TO RUN — ResumeIQ
### Intelligent Resume & Job Match Analyzer
---

This guide is written for someone who is setting up this project for the **first time**
on their own computer. Follow every step carefully.

---

## WHAT YOU NEED BEFORE STARTING

- A Windows, Mac, or Linux computer
- Python installed (version 3.9 or higher)
- Internet connection (only needed during setup to install libraries)
- A resume saved as a **PDF file** (not Word, not image scan — must be a text-based PDF)

---

## STEP 1 — CHECK IF PYTHON IS INSTALLED

Open a terminal (Command Prompt on Windows, Terminal on Mac/Linux) and type:

```
python --version
```

You should see something like:

```
Python 3.11.4
```

If you see an error, download Python from:
👉 https://www.python.org/downloads/

During installation on Windows, **tick the box that says "Add Python to PATH".**

---

## STEP 2 — DOWNLOAD OR COPY THE PROJECT

Make sure you have the full project folder named `Resume_analyzer` somewhere on your
computer. It should look like this inside:

```
Resume_analyzer/
├── main.py
├── resume_parser.py
├── text_processor.py
├── skill_extractor.py
├── job_matcher.py
├── resume_scorer.py
├── role_recommender.py
├── suggestions.py
├── report_generator.py
├── requirements.txt
├── README.md
├── HOW_TO_RUN.md           ← this file
├── WHAT_THIS_DOES.md
│
├── data/
│   ├── skills.json
│   └── roles.json
│
├── sample_resumes/
│   ├── sample_data_analyst.pdf
│   ├── sample_ml_intern.pdf
│   ├── sample_python_dev.pdf
│   ├── sample_flutter_dev.pdf
│   ├── jd_data_analyst.txt
│   ├── jd_python_developer.txt
│   ├── jd_ml_intern.txt
│   └── jd_flutter_developer.txt
│
├── reports/                ← HTML reports appear here automatically
└── tests/
    └── test_all.py
```

---

## STEP 3 — OPEN A TERMINAL INSIDE THE PROJECT FOLDER

**On Windows:**
1. Open the `Resume_analyzer` folder in File Explorer
2. Click on the address bar at the top
3. Type `cmd` and press Enter
4. A black command prompt window will open inside that folder

**On Mac/Linux:**
1. Open Terminal
2. Navigate to the folder using cd:
   ```
   cd path/to/Resume_analyzer
   ```
   For example:
   ```
   cd Desktop/Resume_analyzer
   ```

---

## STEP 4 — CREATE A VIRTUAL ENVIRONMENT (RECOMMENDED)

A virtual environment keeps the libraries for this project separate from your
other Python projects. This is good practice and avoids conflicts.

Type these commands one by one:

**Create the virtual environment:**
```
python -m venv venv
```

**Activate it:**

On Windows:
```
venv\Scripts\activate
```

On Mac/Linux:
```
source venv/bin/activate
```

After activating, you should see `(venv)` at the start of your terminal line.
This means the virtual environment is active.

> If you skip this step, the libraries will install globally on your system,
> which is fine but not recommended.

---

## STEP 5 — INSTALL THE REQUIRED LIBRARIES

With the virtual environment active, run:

```
pip install -r requirements.txt
```

This will install all necessary libraries:
- `pdfplumber` — reads PDF files
- `nltk` — natural language processing
- `scikit-learn` — machine learning tools (TF-IDF)
- `numpy` — numerical operations
- `pandas` — data handling

Wait for the installation to finish. You will see messages like
"Successfully installed pdfplumber...". This may take 1-3 minutes.

---

## STEP 6 — RUN THE APPLICATION

Type:

```
python main.py
```

You will see:

```
════════════════════════════════════════════════
              ResumeIQ
     Intelligent Resume & Job Match Analyzer
════════════════════════════════════════════════

  Enter the path to your resume PDF
  (or type 'q' to quit):
  >
```

---

## STEP 7 — ENTER YOUR RESUME PDF PATH

Type the path to your PDF resume and press Enter.

**If using the included sample resumes:**
```
sample_resumes/sample_data_analyst.pdf
```

**If using your own resume (examples):**

Windows:
```
C:\Users\YourName\Documents\my_resume.pdf
```

Mac/Linux:
```
/home/yourname/Documents/my_resume.pdf
```

> TIP: You can drag and drop your PDF file into the terminal window
> to automatically paste its full path.

---

## STEP 8 — ENTER THE JOB DESCRIPTION

After entering the PDF path, the app asks for a job description:

```
  Paste the job description below.
  Press Enter twice when done (blank line = submit):
```

You can:

**Option A — Use a sample job description:**
Open one of the `.txt` files in the `sample_resumes/` folder with Notepad (or any text editor),
select all the text, copy it, paste it into the terminal, then press Enter twice.

Sample JD files included:
- `sample_resumes/jd_data_analyst.txt`
- `sample_resumes/jd_python_developer.txt`
- `sample_resumes/jd_ml_intern.txt`
- `sample_resumes/jd_flutter_developer.txt`

**Option B — Use a real job description:**
Go to any job posting on LinkedIn, Naukri, Internshala, etc.
Copy the full job description text and paste it into the terminal.
Then press Enter twice to submit.

---

## STEP 9 — WAIT FOR THE ANALYSIS

The app will show progress:

```
  [1/7] Extracting resume text...
     [OK] Extracted text from 1 page(s).
  [2/7] Processing resume text...
     [OK] 124 meaningful tokens found.
  [3/7] Extracting skills from resume...
     [OK] 15 skills detected.
  [4/7] Analysing job description...
     [OK] 10 required skills identified in JD.
  [5/7] Calculating match scores...
     [OK] Skill Match: 80%  |  TF-IDF: 65%  |  Final: 74%
  [6/7] Generating quality score, roles & suggestions...
     [OK] Quality: 85/100  |  3 roles recommended.
  [7/7] Generating HTML report...
     [OK] Report saved to: reports/resume_analysis_20260729_223619.html
```

---

## STEP 10 — VIEW YOUR RESULTS

**In the terminal**, you will see a summary:

```
  Resume Quality Score  : 85/100 (Excellent)
  Skill Match Score     : 80%
  TF-IDF Similarity     : 65%
  Final Job Match       : 74%

  Matched Skills (9):
    [+] Python
    [+] Pandas
    [+] Git
    ...

  Missing Skills (2):
    [-] SQL
    [-] Power BI

  Recommended Roles:
    1. Data Analyst  —  71%
    2. ML Intern  —  58%
    3. Python Developer  —  50%
```

**The full HTML report** is saved inside the `reports/` folder.
Open it with any browser (Chrome, Firefox, Edge) to see the complete visual report with:
- Score circles and progress bars
- Skill badges (matched in green, missing in red)
- Role recommendation cards
- Detailed improvement suggestions

---

## RUNNING THE TESTS

To verify everything is working correctly:

```
python tests/test_all.py
```

You should see:
```
Ran 65 tests in 0.05s
OK
```

---

## COMMON PROBLEMS & FIXES

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError: No module named 'pdfplumber'` | Run `pip install -r requirements.txt` again |
| `File not found: ...` | Check the PDF path — make sure there are no typos |
| `No text could be extracted` | Your PDF is a scanned image — use a text-based PDF instead |
| `python` command not found | Python is not installed or not added to PATH — reinstall Python |
| The report folder doesn't appear | It's created automatically — run the app first |
| Blank or empty results | Make sure the job description has at least 2-3 sentences |

---

## QUICK START (FOR THE IMPATIENT)

If you just want to test it immediately with the included samples:

```
pip install -r requirements.txt
python main.py
```

Then enter:
- Resume path: `sample_resumes/sample_data_analyst.pdf`
- Job description: copy-paste everything from `sample_resumes/jd_data_analyst.txt`

Then open `reports/` and look at the HTML file.

---

## FILES YOU SHOULD KNOW ABOUT

| File/Folder | What it is |
|-------------|-----------|
| `main.py` | The file you run — `python main.py` |
| `requirements.txt` | List of libraries to install |
| `data/skills.json` | The skills dictionary — you can add more skills here |
| `data/roles.json` | The job roles — you can add more roles here |
| `sample_resumes/` | Ready-to-use sample PDFs and job descriptions for testing |
| `reports/` | Where HTML reports are saved after each run |
| `tests/test_all.py` | Automated tests — run to check everything works |

---

*This project requires no internet connection after setup. All analysis runs locally on your computer.*
