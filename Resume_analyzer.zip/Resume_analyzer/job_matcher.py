"""
job_matcher.py
--------------
Compares extracted resume skills against job description skills to compute:
  - Matched skills
  - Missing skills
  - Skill match score (0-100)
  - TF-IDF cosine similarity score (0-100)
  - Final combined job match score (0-100)

Scoring formula
---------------
  skill_match    = matched_required / total_required * 100  (60% weight)
  tfidf_sim      = cosine_similarity(resume_text, jd_text)  (40% weight)
  final_match    = skill_match * 0.60 + tfidf_sim * 0.40
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ── Skill matching ───────────────────────────────────────────────────────────

def match_skills(resume_skills: list[str], jd_skills: list[str]) -> dict:
    """
    Identify matched and missing skills.

    Parameters
    ----------
    resume_skills : list of skill strings detected in the resume
    jd_skills     : list of skill strings required by the job description

    Returns
    -------
    dict with:
        matched   (list[str])  – skills present in both resume and JD
        missing   (list[str])  – skills required by JD but absent in resume
        extra     (list[str])  – skills in resume but not required by JD
        score     (float)      – skill match percentage 0-100
    """
    if not jd_skills:
        return {
            "matched": [],
            "missing": [],
            "extra": resume_skills[:],
            "score": 0.0,
            "note": "No skills detected in the job description.",
        }

    resume_lower = {s.lower() for s in resume_skills}
    jd_lower = {s.lower() for s in jd_skills}

    matched_lower = resume_lower & jd_lower
    missing_lower = jd_lower - resume_lower

    # Preserve original casing from jd_skills and resume_skills
    jd_skill_map = {s.lower(): s for s in jd_skills}
    resume_skill_map = {s.lower(): s for s in resume_skills}

    matched = sorted([jd_skill_map[k] for k in matched_lower])
    missing = sorted([jd_skill_map[k] for k in missing_lower])
    extra = sorted([resume_skill_map[k] for k in resume_lower - jd_lower])

    score = round(len(matched) / len(jd_skills) * 100, 1)
    score = min(score, 100.0)  # safety cap

    return {
        "matched": matched,
        "missing": missing,
        "extra": extra,
        "score": score,
    }


# ── TF-IDF cosine similarity ─────────────────────────────────────────────────

def compute_tfidf_similarity(resume_text: str, jd_text: str) -> float:
    """
    Compute TF-IDF cosine similarity between the resume and job description.

    TF-IDF (Term Frequency – Inverse Document Frequency) converts each text
    into a numeric vector.  Cosine similarity then measures how closely
    aligned the two vectors are (angle between them).

    This is a standard NLP text similarity technique — NOT deep learning.

    Returns
    -------
    float – similarity score as a percentage 0.0 to 100.0
    """
    if not resume_text or not jd_text:
        return 0.0

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),   # unigrams + bigrams for better context
            min_df=1,
            sublinear_tf=True,    # log-normalise term frequency
        )
        vectors = vectorizer.fit_transform([resume_text, jd_text])
        sim = cosine_similarity(vectors[0], vectors[1])[0][0]
        return round(float(sim) * 100, 1)
    except Exception as e:
        print(f"  Warning: TF-IDF similarity calculation failed – {e}")
        return 0.0


# ── Combined final score ─────────────────────────────────────────────────────

def compute_final_score(skill_match_score: float, tfidf_score: float) -> int:
    """
    Compute the final job match score using a weighted combination.

    Weights
    -------
    60% skill match  (hard skill overlap is the strongest signal)
    40% TF-IDF sim   (broader context similarity)

    Returns
    -------
    int – final score 0 to 100
    """
    raw = (skill_match_score * 0.60) + (tfidf_score * 0.40)
    return int(min(max(round(raw), 0), 100))


# ── Master analysis function ─────────────────────────────────────────────────

def analyse_match(
    resume_skills: list[str],
    jd_skills: list[str],
    resume_text: str,
    jd_text: str,
) -> dict:
    """
    Run the full matching pipeline.

    Returns
    -------
    dict with all component scores and skill lists.
    """
    skill_result = match_skills(resume_skills, jd_skills)
    tfidf_score = compute_tfidf_similarity(resume_text, jd_text)
    final_score = compute_final_score(skill_result["score"], tfidf_score)

    return {
        "matched_skills": skill_result["matched"],
        "missing_skills": skill_result["missing"],
        "extra_skills": skill_result["extra"],
        "skill_match_score": skill_result["score"],
        "tfidf_score": tfidf_score,
        "final_match_score": final_score,
    }
